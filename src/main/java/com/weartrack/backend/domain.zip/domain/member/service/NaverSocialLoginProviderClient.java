package com.weartrack.backend.domain.member.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.weartrack.backend.domain.member.constant.AuthProvider;
import com.weartrack.backend.domain.member.dto.SocialUserInfo;
import com.weartrack.backend.domain.member.exception.AuthErrorCode;
import com.weartrack.backend.global.exception.GeneralException;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientException;

/**
 * Naver 소셜 로그인 연동을 처리한다.
 */
@Component
public class NaverSocialLoginProviderClient implements SocialLoginProviderClient {

    private static final String TOKEN_URI = "https://nid.naver.com/oauth2.0/token";
    private static final String USER_INFO_URI = "https://openapi.naver.com/v1/nid/me";

    private final RestClient restClient;
    private final String clientId;
    private final String clientSecret;
    private final String redirectUri;

    public NaverSocialLoginProviderClient(
            RestClient restClient,
            @Value("${NAVER_CLIENT_ID}") String clientId,
            @Value("${NAVER_CLIENT_SECRET}") String clientSecret,
            @Value("${NAVER_REDIRECT_URI}") String redirectUri
    ) {
        this.restClient = restClient;
        this.clientId = clientId;
        this.clientSecret = clientSecret;
        this.redirectUri = redirectUri;
    }

    /**
     * 현재 구현체가 처리하는 제공자를 반환한다.
     */
    @Override
    public AuthProvider supports() {
        return AuthProvider.NAVER;
    }

    /**
     * Naver 인가 코드를 access token으로 교환한 뒤 사용자 정보를 조회합니다.
     */
    @Override
    public SocialUserInfo getUserInfo(String authorizationCode, String state) {
        try {
            String accessToken = exchangeCodeForAccessToken(authorizationCode, state);
            JsonNode body = restClient.get()
                    .uri(USER_INFO_URI)
                    .header(HttpHeaders.AUTHORIZATION, "Bearer " + accessToken)
                    .retrieve()
                    .body(JsonNode.class);

            JsonNode response = body == null ? null : body.path("response");

            return new SocialUserInfo(
                    supports(),
                    getRequiredText(response, "id"),
                    getOptionalText(response, "email")
            );
        } catch (RestClientException e) {
            throw new GeneralException(AuthErrorCode.INVALID_SOCIAL_TOKEN);
        }
    }

    /**
     * Naver token endpoint와 통신해 authorization code를 access token으로 교환합니다.
     */
    private String exchangeCodeForAccessToken(String authorizationCode, String state) {
        MultiValueMap<String, String> formData = new LinkedMultiValueMap<>();
        formData.add("code", authorizationCode);
        formData.add("client_id", clientId);
        formData.add("client_secret", clientSecret);
        formData.add("redirect_uri", redirectUri);
        formData.add("grant_type", "authorization_code");

        if (state != null && !state.isBlank()) {
            formData.add("state", state);
        }

        JsonNode body = restClient.post()
                .uri(TOKEN_URI)
                .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                .body(formData)
                .retrieve()
                .body(JsonNode.class);

        return getRequiredText(body, "access_token");
    }

    private String getRequiredText(JsonNode body, String fieldName) {
        if (body == null || body.path(fieldName).asText().isBlank()) {
            throw new GeneralException(AuthErrorCode.SOCIAL_USER_INFO_NOT_FOUND);
        }
        return body.path(fieldName).asText();
    }

    private String getOptionalText(JsonNode body, String fieldName) {
        if (body == null || body.path(fieldName).isMissingNode() || body.path(fieldName).asText().isBlank()) {
            return null;
        }
        return body.path(fieldName).asText();
    }
}
